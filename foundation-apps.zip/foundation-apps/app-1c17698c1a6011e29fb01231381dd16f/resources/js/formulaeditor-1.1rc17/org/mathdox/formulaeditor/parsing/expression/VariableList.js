$package("org.mathdox.formulaeditor.parsing.expression");

$identify("org/mathdox/formulaeditor/parsing/expression/VariableList.js");

$main(function(){
  org.mathdox.formulaeditor.parsing.expression.VariableList = {};
});
