$package("org.mathdox.formulaeditor.parsing.openmath");

$identify("org/mathdox/formulaeditor/parsing/openmath/VariableList.js");

$main(function(){
  org.mathdox.formulaeditor.parsing.openmath.VariableList = {};
});
